import { Router } from "express";
import { NgoMiddleware } from "./Middleware/AuthMiddleware";
import eventController from "../Controller/event.controller";

const ngoRouter = Router();

ngoRouter.route("/register").post(NgoMiddleware, eventController.store);

export default ngoRouter;

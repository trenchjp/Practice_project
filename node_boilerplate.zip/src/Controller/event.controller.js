import asyncErrorHandler from "../Utils/asyncErrorHandler";
import { CreateEventValidator } from "../Utils/Validator/UserValidator";

const store = asyncErrorHandler(async (req, res, next) => {
  const { error } = CreateEventValidator.validate(req.body);
  if (error)
    return next({
      statusCode: constants.UNPROCESSABLE_ENTITY,
      message: error.details[0].message,
    });

  console.log("req.body", req.body);
  return res.status(constants.CREATED).json({
    success: true,
    message: "Event created successfully",
    data: {},
  });
});

const eventController = {
  store,
};

export default eventController;

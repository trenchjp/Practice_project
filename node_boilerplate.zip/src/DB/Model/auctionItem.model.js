import mongoose from "mongoose";

const auctionItemSchema = mongoose.Schema(
  {
    event: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Event",
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    starting_bid_price: {
      type: String,
      required: true,
      trim: true,
    },
    start_time: {
      type: String,
      required: true,
      trim: true,
    },
    end_time: {
      type: String,
      required: true,
      trim: true,
    },
    images: {
      type: [mongoose.Schema.Types.ObjectId],
      required: true,
      ref: "fileUpload",
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
    highest_bid: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
      ref: "Bid",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
  }
);

const AuctionItem = mongoose.model("AuctionItem", auctionItemSchema);

/**
 * @typedef AuctionItem
 */

export default AuctionItem;

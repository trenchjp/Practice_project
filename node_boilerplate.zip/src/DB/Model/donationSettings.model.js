import mongoose from "mongoose";

const donationSettingSchema = mongoose.Schema(
  {
    event: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Event",
    },
    pre_defined_amount: {
      type: [Number],
      required: true,
      default: [],
    },
    allow_custom_amount: {
      type: Boolean,
      required: true,
      default: false,
    },
    allow_virtual_participants: {
      type: Boolean,
      required: true,
      default: false,
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
  }
);

const DonationSetting = mongoose.model(
  "DonationSetting",
  donationSettingSchema
);

/**
 * @typedef DonationSetting
 */

export default DonationSetting;

import mongoose from "mongoose";

const eventSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    date: {
      type: Date,
      required: true,
    },
    time: {
      type: String,
      required: true,
      trim: true,
    },
    event_type: {
      type: [String],
      required: true,
      enum: ["Raffle", "Auction", "Donation"],
      default: [],
    },
    status: {
      type: String,
      required: true,
      enum: ["upcoming", "ongoing", "completed"],
      default: "upcoming",
    },
    images: {
      type: [mongoose.Schema.Types.ObjectId],
      required: false,
      ref: "fileUpload",
    },
    location: {
      type: String,
      required: true,
      trim: true,
    },
    organizer: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
  }
);

const Event = mongoose.model("Event", eventSchema);

/**
 * @typedef Event
 */

export default Event;

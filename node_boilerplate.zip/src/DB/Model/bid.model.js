import mongoose from "mongoose";

const bidSchema = mongoose.Schema(
  {
    event: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Event",
    },
    auction_item: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "AuctionItem",
    },
    bid_amount: {
      type: Number,
      required: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
  }
);

const Bid = mongoose.model("Bid", bidSchema);

/**
 * @typedef Bid
 */

export default Bid;

import mongoose from "mongoose";

const donationSchema = mongoose.Schema(
  {
    event: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Event",
    },
    amount: {
      type: Number,
      required: true,
    },
    message: {
      type: String,
      required: false,
      trim: true,
    },
    anonymous_donation: {
      type: Boolean,
      required: true,
      default: false,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
  }
);

const Donation = mongoose.model("Donation", donationSchema);

/**
 * @typedef Donation
 */

export default Donation;

import mongoose from "mongoose";

const raffleTicketSchema = mongoose.Schema(
  {
    event: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "Event",
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    ticket_price: {
      type: String,
      required: true,
      trim: true,
    },
    total_tickets: {
      type: Number,
      required: true,
      default: 0,
    },
    max_tickets_per_user: {
      type: Number,
      required: true,
      default: 1,
    },
    start_time: {
      type: String,
      required: true,
      trim: true,
    },
    end_time: {
      type: String,
      required: true,
      trim: true,
    },
    images: {
      type: [mongoose.Schema.Types.ObjectId],
      required: true,
      ref: "fileUpload",
    },
    created_by: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "User",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    versionKey: false,
  }
);

const RaffleTicket = mongoose.model("RaffleTicket", raffleTicketSchema);

/**
 * @typedef RaffleTicket
 */

export default RaffleTicket;
